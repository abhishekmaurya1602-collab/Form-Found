# Form & Found — Product Museum (Phase 1 Prototype)

A responsive, interactive single-page prototype featuring an editorial collection, Art ↔ Artist navigation, filters, search, Surprise Me discovery, a history timeline, scroll reveals, a progress indicator, parallax, and reduced-motion support.

## Run
Open `index.html` in a browser, or serve with `python3 -m http.server 8000` and visit http://localhost:8000.

## Production notes
This is a design/prototype build, not a ready-to-publish museum database. Content entries are illustrative and should be fact-checked with primary museum/creator sources, particularly collaborative credits. Some externally hosted Wikimedia images may be unavailable or require corrected paths. Verify and license all imagery prior to publication. Add a CMS, structured source citations, archival evidence, patent identifiers, provenance, localization, accessibility QA, and persistent collections in later phases.

## Suggested next architecture
- Next.js + TypeScript + Tailwind CSS or CSS modules
- Motion for React / GSAP ScrollTrigger only where interaction benefits
- Headless CMS (Sanity or Payload)
- Entities: object, person, studio, manufacturer, movement, patent, version, source, relationship
- Data relationships: DESIGNED_BY, INSPIRED_BY, MANUFACTURED_BY, VERSION_OF, DOCUMENTED_IN
